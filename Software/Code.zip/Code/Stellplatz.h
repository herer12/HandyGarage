#ifndef STELLPLATZ_H
#define STELLPLATZ_H

#include "Strommessung.h"
#include "Konfig.h"

class Stellplatz {
public:
    Stellplatz(Strommessung& strommessung);
    void setupStrommessung();

    float* getLoadvoltage();
    float* getCurrent_A();
    float* getPower_W();

private:
    Strommessung& _strommessung;

    float _loadvoltage_V[5] = {};
    float _current_A[5] = {};
    float _power_W[5] = {};
};

#endif
