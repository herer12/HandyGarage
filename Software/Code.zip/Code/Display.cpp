#include "Display.h"

Display::Display(int8_t sda, int8_t scl, uint8_t i2cAddress, TwoWire &wire, uint32_t i2cClock)
    : _sda(sda),
      _scl(scl),
      _addr(i2cAddress),
      _wire(wire),
      _clock(i2cClock),
      _oled(WIDTH, HEIGHT, &wire, -1) {}   // -1 = kein Reset-Pin

bool Display::begin() {
    _wire.begin(_sda, _scl);
    _wire.setClock(_clock);

    // reset = true, periphBegin = false (Wire wurde oben schon gestartet)
    if (!_oled.begin(SSD1306_SWITCHCAPVCC, _addr, true, false)) {
        Serial.println(F("SSD1306: Initialisierung fehlgeschlagen (Adresse/Verkabelung pruefen)"));
        _ready = false;
        return false;
    }

    _oled.setTextColor(SSD1306_WHITE);
    _oled.setTextWrap(false);
    _oled.clearDisplay();
    _oled.display();
    _ready = true;
    return true;
}

void Display::clear() {
    _oled.clearDisplay();
}

void Display::show() {
    _oled.display();
}

void Display::printText(int16_t x, int16_t y, const String &text, uint8_t size) {
    _oled.setTextSize(size);
    _oled.setCursor(x, y);
    _oled.print(text);
}

void Display::printLine(uint8_t line, const String &text, uint8_t size) {
    printText(0, line * 8 * size, text, size);
}

void Display::printCentered(int16_t y, const String &text, uint8_t size) {
    int16_t x1, y1;
    uint16_t w, h;
    _oled.setTextSize(size);
    _oled.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
    _oled.setCursor((WIDTH - w) / 2, y);
    _oled.print(text);
}

void Display::drawProgressBar(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t percent) {
    if (percent > 100) percent = 100;
    _oled.drawRect(x, y, w, h, SSD1306_WHITE);
    int16_t fill = ((w - 4) * percent) / 100;
    _oled.fillRect(x + 2, y + 2, fill, h - 4, SSD1306_WHITE);
}

void Display::showMessage(const String &title, const String &message) {
    clear();
    printCentered(0, title, 1);
    _oled.drawFastHLine(0, 11, WIDTH, SSD1306_WHITE);
    printCentered(26, message, 2);
    show();
}

void Display::setBrightness(uint8_t value) {
    _oled.ssd1306_command(SSD1306_SETCONTRAST);
    _oled.ssd1306_command(value);
}

void Display::setPower(bool on) {
    _oled.ssd1306_command(on ? SSD1306_DISPLAYON : SSD1306_DISPLAYOFF);
}

void Display::invert(bool inverted) {
    _oled.invertDisplay(inverted);
}

void Display::setRotation(uint8_t rotation) {
    _oled.setRotation(rotation);
}
