#pragma once

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

/**
 * Wrapper-Klasse für ein SSD1306 OLED (128x64, I2C) am ESP32-S3.
 *
 * Benötigte Bibliotheken (Arduino Library Manager / PlatformIO):
 *   - Adafruit SSD1306
 *   - Adafruit GFX Library
 */
class Display {
public:
    static constexpr uint8_t WIDTH  = 128;
    static constexpr uint8_t HEIGHT = 64;

    // Standard-I2C-Pins des ESP32-S3-DevKitC-1: SDA = GPIO8, SCL = GPIO9
    // -> bei anderen Boards einfach anpassen.
    Display(int8_t sda = 8,
            int8_t scl = 9,
            uint8_t i2cAddress = 0x3C,
            TwoWire &wire = Wire,
            uint32_t i2cClock = 400000);

    bool begin();

    // --- Zeichnen / Puffer ---
    void clear();
    void show();                                   // Puffer ans Display senden

    void printText(int16_t x, int16_t y, const String &text, uint8_t size = 1);
    void printLine(uint8_t line, const String &text, uint8_t size = 1);   // Zeile à 8 px * size
    void printCentered(int16_t y, const String &text, uint8_t size = 1);
    void drawProgressBar(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t percent);

    // Komfort: löscht, schreibt Titel + Wert und zeigt an
    void showMessage(const String &title, const String &message);

    // --- Einstellungen ---
    void setBrightness(uint8_t value);             // 0..255
    void setPower(bool on);                        // Display an/aus
    void invert(bool inverted);
    void setRotation(uint8_t rotation);            // 0..3

    // Direkter Zugriff auf Adafruit_GFX-Funktionen (Linien, Kreise, Bitmaps, ...)
    Adafruit_SSD1306 &raw() { return _oled; }

    bool isReady() const { return _ready; }

private:
    int8_t   _sda;
    int8_t   _scl;
    uint8_t  _addr;
    TwoWire &_wire;
    uint32_t _clock;
    bool     _ready = false;
    Adafruit_SSD1306 _oled;
};
