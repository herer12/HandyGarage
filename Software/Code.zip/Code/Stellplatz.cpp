#include "Stellplatz.h"

Stellplatz::Stellplatz(Strommessung& strommessung)
    : _strommessung(strommessung) {
}

void Stellplatz::setupStrommessung(){

}

float* Stellplatz::getLoadvoltage() {
    return _loadvoltage_V;
}

float* Stellplatz::getCurrent_A() {
    return _current_A;
}

float* Stellplatz::getPower_W() {
    return _power_W;
}

