#include "Display.h"
Display display(A4, A5, 0x3C);

void setup(){
    Serial.begin(115200);

    if (!display.begin()) {
        while (true) delay(1000);   // Display nicht gefunden
    }

    display.showMessage("ESP32-S3", "Hallo!");
    delay(1500);
}
void loop(){

}